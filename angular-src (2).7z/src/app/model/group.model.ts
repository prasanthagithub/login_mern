export default class Group {
    _id: string;
    name: string;
    description: string;
    // _userId: string;
    abcd: string;
}
