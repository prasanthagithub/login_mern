export default class User {
    _id: string;
    messageText: string;
    _groupId: string;
    image: string;
}
