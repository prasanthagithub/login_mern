import { Component } from '@angular/core';

@Component({
  selector: 'app-root', // this is the html tag that we can use to insert the component.
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-src';
}
